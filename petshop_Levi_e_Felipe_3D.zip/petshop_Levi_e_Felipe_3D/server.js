const express = require('express');
const cors = require('cors');
const mysql = require('mysql2/promise');
const multer = require('multer');
const express = require('express');

app.use('/uploads', express.static(path.join(__dirname, 'uploads')));

const db = mysql.createPool({
    host: 'localhost',
    user:'admin',
    password: '1234',
    database: 'login',
    port: 3306,
});

const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'uploads/');
    },
        filename: (req, file, cb) => {
            cb(null, Date.now( + path.extname(file.originalname)))
        }
});
const upload = multer({stoage});

app.post('api/pets', upload.single('imagem'), async (req, res) => {
    const {tutor, nome_pet, raca, genero, peso, idade} = req.body;
    const imagem_url = req.file? `/uploads/${req.file.filename}` : null;


    if(!tutor || !nome_pet || !raca || !genero || !peso || !idade || !imagem_url){
        return res.status(400).json({message: 'Todos os campos e a imagem são obrigatórios'});
    }

    try{
        const query = `
            INSERT INTO pets (tutor, nome_pet, raca, genero, peso, idade, imagem_url)
            VALUES (?, ?, ?, ?, ?, ?, ?)
        `;

        await db.query(query, [tutor, nome_pet, raca, genero, peso, idade, imagem_url]);

        return res.status(201).json({message: 'Pet cadastro com sucesso!'});

    } catch (error){
        console.error('Erro ao soltar pet:', error);
        return res.status(500).json({message: 'Erro ao salvar no banco de Dados'})
    }
});